#include <iostream>
#include <vector>

using std::endl;
using std::vector;
using std::cout;

 //Blank A
struct node {
 //Blank B	
 	int val;
 	node* next;
};
 
void create_LL(vector<node*>& mylist, int node_num){
    mylist.assign(node_num, NULL); // create a new vector with new node to fix segmentation error
    //de-reference the mylist[i] as a pointer instead of as a value

    for(int i = 0; i < node_num; i++){ // Runtime Error Fix (Null-Pointer)
        mylist[i]=new node (); // initalize all the node in that mylist vector
    }

    for (int i = 0; i < node_num; i++) {
        //Blank C
        mylist[i]->val = i; // fix . to ->
        mylist[i]->next = NULL;
    }



    //create a linked list
    for (int i = 0; i < node_num-1; i++) { // need to change to node_num-1 since it will out of bound when it reach the last index
        mylist[i]->next = mylist[i+1];
    }
}

int sum_LL(node* ptr) {
    int ret = 0;
    while(ptr) {
        ret += ptr->val; // fix . to ->
        ptr = ptr->next;
        //cout<<ret<<endl;
    }
    return ret;
}

int main(int argc, char ** argv){
    const int NODE_NUM = 3;
    vector<node*> mylist;

    create_LL(mylist, NODE_NUM);
    int ret = sum_LL(mylist[0]); 
    std::cout << "The sum of nodes in LL is " << ret << endl;

    //Step4: delete nodes

    
    for (int i = 0; i < NODE_NUM; i++){
        delete mylist[i];
    }

    //Blank D
}